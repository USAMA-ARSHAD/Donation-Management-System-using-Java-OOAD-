/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooadproject;

import java.sql.Time;
import java.util.Date;

/**
 *
 * @author Lenovo
 */
public class Interview {
    private Assesor interviewer;
    private Applicant interviewee;
    Date date;
    Time time;
    boolean need_for_another;
    
    public void reconduct()
    {
        
    }
    
    public void pass()
    {
        
    }
    
    public void fail()
    {
        
    }
}
