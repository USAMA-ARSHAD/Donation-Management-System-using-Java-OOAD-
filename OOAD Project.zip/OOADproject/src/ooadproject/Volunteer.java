/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooadproject;

import java.sql.Time;

/**
 *
 * @author Lenovo
 */
public class Volunteer extends User{
    Time schedule_time;
}
